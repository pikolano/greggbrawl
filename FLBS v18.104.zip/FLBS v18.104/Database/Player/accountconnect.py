import json
import os
from telebot import TeleBot, types

# Токен вашего Telegram-бота
API_TOKEN = "8087892440:AAEHVohrFXWW78-04Aw-8AKSSeXVvazbrPQ"

# Инициализация бота
bot = TeleBot(API_TOKEN)

# Пути к файлам
PLAYERS_FILE = "data.db"
TOKENS_FILE = "tokens.txt"

# Проверяем наличие файлов и создаём, если их нет
if not os.path.exists(PLAYERS_FILE):
    with open(PLAYERS_FILE, "w") as f:
        json.dump({"_default": {}}, f)

if not os.path.exists(TOKENS_FILE):
    open(TOKENS_FILE, "w").close()


@bot.message_handler(commands=["start"])
def start_command(message):
    """
    Обработчик команды /start
    """
    response = (
        "Добро пожаловать! Вот доступные команды:\n"
        "/register <lowid> <token> - Регистрация или обновление токена аккаунта."
    )
    bot.send_message(message.chat.id, response)


@bot.message_handler(commands=["register"])
def register_command(message):
    """
    Обработчик команды /register
    """
    try:
        # Разбиваем сообщение на части
        parts = message.text.split()
        if len(parts) != 3:
            raise ValueError("Некорректное количество аргументов.")

        lowid = int(parts[1])  # Преобразуем lowid в число
        token = parts[2]

        # Загружаем players.json
        with open(PLAYERS_FILE, "r") as f:
            players_data = json.load(f)

        # Проверяем, существует ли токен в players.json
        token_found = False
        for account_id, account_data in players_data["_default"].items():
            if account_data["token"] == token:
                token_found = True
                if account_data["info"]["lowID"] == lowid:
                    raise ValueError(f"Токен '{token}' уже привязан к LowID {lowid}.")
                break

        if not token_found:
            raise ValueError(f"Токен '{token}' отсутствует в players.json.")

        # Ищем аккаунт с указанным lowid
        found = False
        for account_id, account_data in players_data["_default"].items():
            # Если токен найден, обнуляем его
            if account_data["token"] == token:
                account_data["token"] = ""

            # Привязываем токен к указанному lowid
            if account_data["info"]["lowID"] == lowid:
                account_data["token"] = token
                found = True

        if not found:
            raise ValueError(f"LowID {lowid} не найден в players.json.")

        # Сохраняем изменения в players.json
        with open(PLAYERS_FILE, "w") as f:
            json.dump(players_data, f, ensure_ascii=False, indent=4)

        # Сохраняем токен в tokens.txt
        with open(TOKENS_FILE, "a") as f:
            f.write(f"{token}\n")

        # Ответ пользователю
        bot.send_message(
            message.chat.id,
            f"Токен успешно сохранён и привязан к LowID {lowid}.",
        )

    except ValueError as e:
        bot.send_message(message.chat.id, f"{e}")
    except Exception as e:
        bot.send_message(
            message.chat.id,
            f"Произошла ошибка: {e}\nПроверьте корректность команды и данные.",
        )


if __name__ == "__main__":
    print("Бот запущен!")
    bot.polling(none_stop=True)