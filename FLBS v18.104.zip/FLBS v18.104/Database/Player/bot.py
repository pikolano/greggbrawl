import telebot
import json

# Создаём бота
admin = [5500056942]
bot = telebot.TeleBot('8087892440:AAEHVohrFXWW78-04Aw-8AKSSeXVvazbrPQ')

# Путь к JSON файлу
json_file_path = 'data.db'

# Функция для получения данных игрока из JSON файла
def get_user_data(user_id):
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get("_default", {}).get(str(user_id), None)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        return None

# Функция для обновления данных игрока в JSON файле
def update_user_data(user_id, data):
    try:
        with open(json_file_path, 'r+', encoding='utf-8') as f:
            all_data = json.load(f)
            all_data["_default"][str(user_id)] = data
            f.seek(0)
            json.dump(all_data, f, ensure_ascii=False, indent=4)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        pass

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id
    if user_id in admin:
        bot.reply_to(
            message,
            "/add_gems - Выдать гемы игроку.\n"
            "/add_gold - Выдать монеты игроку.\n"
            "/add_trophies - Выдать трофеи игроку.\n"
            "/info - Показать информацию об аккаунте игрока."
        )
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_gems'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Правильное использование: /add_gems ID AMOUNT")
        else:
            id = int(message.text.split()[1])
            amount = int(message.text.split()[2])
            data = get_user_data(id)
            if data:
                data['info']['gems'] += amount
                update_user_data(id, data)
                bot.send_message(chat_id=message.chat.id, text=f"Игроку с ID {id} выдано {amount} гемов.")
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_gold'])
def add_gold(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Правильное использование: /add_gold ID AMOUNT")
        else:
            id = int(message.text.split()[1])
            amount = int(message.text.split()[2])
            data = get_user_data(id)
            if data:
                data['info']['gold'] += amount
                update_user_data(id, data)
                bot.send_message(chat_id=message.chat.id, text=f"Игроку с ID {id} выдано {amount} монет.")
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_trophies'])
def add_trophies(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Правильное использование: /add_trophies ID AMOUNT")
        else:
            id = int(message.text.split()[1])
            amount = int(message.text.split()[2])
            data = get_user_data(id)
            if data:
                data['info']['trophies'] += amount
                update_user_data(id, data)
                bot.send_message(chat_id=message.chat.id, text=f"Игроку с ID {id} выдано {amount} трофеев.")
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['info'])
def show_info(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование: /info ID")
        else:
            id = int(message.text.split()[1])
            data = get_user_data(id)
            if data:
                info = data['info']
                response = (
                    f"Информация об аккаунте игрока с ID {id}:\n"
                    f"Имя: {info['name']}\n"
                    f"Гемы: {info['gems']}\n"
                    f"Монеты: {info['gold']}\n"
                    f"Трофеи: {info['trophies']}\n"
                    f"Победы в одиночных боях: {info['soloWins']}\n"
                    f"Победы в дуо: {info['duoWins']}\n"
                    f"Победы в 3х3: {info['3vs3Wins']}\n"
                    f"Заблокирован: {'Да' if info.get('banned', False) else 'Нет'}"
                )
                bot.send_message(chat_id=message.chat.id, text=response)
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Запускаем бота
bot.polling()