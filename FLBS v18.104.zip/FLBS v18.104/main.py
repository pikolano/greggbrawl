import logging
import socket
import time
import os
import json
import random
from threading import *

from Logic.Device import Device
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Utils.Config import Config

# logging.basicConfig(filename="errors.log", level=logging.INFO, filemode="w")


def _(message):
    print('[INFO]', message)


class Server:
    Clients = {"ClientCounts": 0, "Clients": {}}
    ThreadCount = 0

    def __init__(self, ip: str, port: int):
        self.server = socket.socket()
        self.port = port
        self.ip = ip

    def start(self):
        # Вставка ASCII-арта
        ascii_art = """
  ______ _      ____   _____    __      ____  ___  
 |  ____| |    |  _ \ / ____|   \ \    / /_ |/ _ \ 
 | |__  | |    | |_) | (___ _____\ \  / / | | (_) |
 |  __| | |    |  _ < \___ \______\ \/ /  | |> _ < 
 | |    | |____| |_) |____) |      \  /   | | (_) |
 |_|    |______|____/|_____/        \/    |_|\___/ 
                                                   
"""
        print(ascii_art)  # Печать ASCII-арта

        if not os.path.exists('./config.json'):
            print("Creating config.json...")
            Config.create_config(self)
        else:
            self.update_theme_id()

        self.server.bind((self.ip, self.port))
        _(f'Core started! Ip: {self.ip}, Port: {self.port}')
        while True:
            self.server.listen()
            client, address = self.server.accept()
            _(f'New connection! Ip: {address[0]}')
            ClientThread(client, address).start()
            Server.ThreadCount += 1

    @staticmethod
    def update_theme_id():
        try:
            with open('config.json', 'r') as config_file:
                config_data = json.load(config_file)

            # Update ThemeID with a random value from 1 to 6
            config_data["ThemeID"] = random.randint(0, 6)

            with open('config.json', 'w') as config_file:
                json.dump(config_data, config_file, indent=4)

            print(f"[INFO] ThemeID updated to {config_data['ThemeID']} in config.json.\n[INFO] FLBS v18.104 is started, have fun.\n[INFO] FLBS Core is launched.")
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"[ERROR] Failed to update ThemeID: {e}")


class ClientThread(Thread):
    def __init__(self, client, address):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)

    def recvall(self, length: int):
        data = b''
        while len(data) < length:
            s = self.client.recv(length)
            if not s:
                print("Receive Error!")
                break
            data += s
        return data

    def run(self):
        last_packet = time.time()
        try:
            while True:
                header = self.client.recv(7)
                if len(header) > 0:
                    last_packet = time.time()
                    packet_id = int.from_bytes(header[:2], 'big')
                    length = int.from_bytes(header[2:5], 'big')
                    data = self.recvall(length)

                    if packet_id in packets:
                        _(f'Received packet! Id: {packet_id}')
                        message = packets[packet_id](self.client, self.player, data)
                        message.decode()
                        message.process()

                        if packet_id == 10101:
                            Server.Clients["Clients"][str(self.player.low_id)] = {"SocketInfo": self.client}
                            Server.Clients["ClientCounts"] = Server.ThreadCount
                            self.player.ClientDict = Server.Clients

                    else:
                        _(f'Packet not handled! Id: {packet_id}')

                if time.time() - last_packet > 10:
                    print(f"[INFO] Ip: {self.address[0]} disconnected!")
                    self.client.close()
                    break
        except (ConnectionAbortedError, ConnectionResetError, TimeoutError):
            print(f"[INFO] Ip: {self.address[0]} disconnected!")
            self.client.close()


if __name__ == '__main__':
    server = Server('127.0.0.1', 9339)
    server.start()