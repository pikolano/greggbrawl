import telebot
import json

# Создаём бота
admin = [5500056942]
bot = telebot.TeleBot('8087892440:AAEHVohrFXWW78-04Aw-8AKSSeXVvazbrPQ')

# Пути к JSON файлам
json_file_path = 'Database/Player/data.db'
banned_file_path = 'JSON/banned.json'

# Функция для получения данных игрока из JSON файла
def get_user_data(user_id):
    try:
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get("_default", {}).get(str(user_id), None)
    except (FileNotFoundError, json.JSONDecodeError):
        return None

# Функция для обновления данных игрока в JSON файле
def update_user_data(user_id, data):
    try:
        with open(json_file_path, 'r+', encoding='utf-8') as f:
            all_data = json.load(f)
            all_data["_default"][str(user_id)] = data
            f.seek(0)
            json.dump(all_data, f, ensure_ascii=False, indent=4)
    except (FileNotFoundError, json.JSONDecodeError):
        pass

# Функция для проверки, заблокирован ли игрок
def is_banned(low_id):
    try:
        with open(banned_file_path, 'r', encoding='utf-8') as f:
            banned_data = json.load(f)
        return low_id in banned_data.get("banned_low_id", [])
    except (FileNotFoundError, json.JSONDecodeError):
        return False

# Функция для блокировки игрока
def ban_player(low_id):
    try:
        with open(banned_file_path, 'r+', encoding='utf-8') as f:
            banned_data = json.load(f)
            if low_id not in banned_data["banned_low_id"]:
                banned_data["banned_low_id"].append(low_id)
                f.seek(0)
                json.dump(banned_data, f, ensure_ascii=False, indent=4)
    except (FileNotFoundError, json.JSONDecodeError):
        with open(banned_file_path, 'w', encoding='utf-8') as f:
            json.dump({"banned_low_id": [low_id]}, f, ensure_ascii=False, indent=4)

# Функция для разблокировки игрока
def unban_player(low_id):
    try:
        with open(banned_file_path, 'r+', encoding='utf-8') as f:
            banned_data = json.load(f)
            if low_id in banned_data["banned_low_id"]:
                banned_data["banned_low_id"].remove(low_id)
                f.seek(0)
                f.truncate()
                json.dump(banned_data, f, ensure_ascii=False, indent=4)
    except (FileNotFoundError, json.JSONDecodeError):
        pass

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id
    if user_id in admin:
        bot.reply_to(
            message,
            "/add_gems - Выдать гемы игроку.\n"
            "/add_gold - Выдать монеты игроку.\n"
            "/add_trophies - Выдать трофеи игроку.\n"
            "/info - Показать информацию об аккаунте игрока.\n"
            "/ban - Заблокировать игрока.\n"
            "/unban - Разблокировать игрока."
        )
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_gems'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Правильное использование: /add_gems ID AMOUNT")
        else:
            id = int(message.text.split()[1])
            amount = int(message.text.split()[2])
            data = get_user_data(id)
            if data:
                data['info']['gems'] += amount
                update_user_data(id, data)
                bot.send_message(chat_id=message.chat.id, text=f"Игроку с ID {id} выдано {amount} гемов.")
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['info'])
def show_info(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование: /info ID")
        else:
            id = int(message.text.split()[1])
            data = get_user_data(id)
            if data:
                info = data['info']
                banned_status = is_banned(info['lowID'])
                response = (
                    f"Информация об аккаунте игрока с ID {id}:\n"
                    f"Имя: {info['name']}\n"
                    f"Гемы: {info['gems']}\n"
                    f"Монеты: {info['gold']}\n"
                    f"Трофеи: {info['trophies']}\n"
                    f"Победы в одиночных боях: {info['soloWins']}\n"
                    f"Победы в дуо: {info['duoWins']}\n"
                    f"Победы в 3х3: {info['3vs3Wins']}\n"
                    f"Заблокирован: {'Да' if banned_status else 'Нет'}"
                )
                bot.send_message(chat_id=message.chat.id, text=response)
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['ban'])
def ban(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование: /ban ID")
        else:
            id = int(message.text.split()[1])
            data = get_user_data(id)
            if data:
                low_id = data['info']['lowID']
                ban_player(low_id)
                bot.send_message(chat_id=message.chat.id, text=f"Игрок с ID {id} и lowID {low_id} заблокирован.")
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['unban'])
def unban(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование: /unban ID")
        else:
            id = int(message.text.split()[1])
            data = get_user_data(id)
            if data:
                low_id = data['info']['lowID']
                unban_player(low_id)
                bot.send_message(chat_id=message.chat.id, text=f"Игрок с ID {id} и lowID {low_id} разблокирован.")
            else:
                bot.reply_to(message, f"Игрок с ID {id} не найден.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Запускаем бота
bot.polling()